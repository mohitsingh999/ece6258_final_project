function testSimple
%testSimple Simple M-file test that passes

%   Steven L. Eddins
%   Copyright 2008 The MathWorks, Inc.